public class Main {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        Memory.getInstance().setValue("a", 2);
        Memory.getInstance().setValue("b", 1);

        ExpressionNode num1 = new NumberNode(10);
        ExpressionNode var1 = new VariableNode("a");

        ExpressionNode exp1 = new InfixExpression(var1, '*', num1);
        ExpressionNode exp2 = new InfixExpression(new VariableNode("b"), '+', exp1); // exp2 = b + a * 10
        ExpressionNode exp3 = new InfixExpression(exp2, '^',
                new InfixExpression(new NumberNode(2), '+', var1)); // exp3 = (b + a * 10) ^ (2 + a)

        System.out.println("Value of num1 is: " + num1.eval());
        System.out.println("Value of var1 is: " + var1.eval());
        System.out.println("Value of exp1 is: " + exp1.eval());
        System.out.println("Value of " + exp2 + " is: " + exp2.eval());

        Memory.getInstance().setValue("a", 5);

        System.out.println("Value of " + exp3 + " is: " + exp3.eval());

        CountVariableVisitor visitor = new CountVariableVisitor();
        exp3.accept(visitor);
        System.out.println("Number of distinct variables in " + exp3 + ": " + visitor.count());

    }
}
