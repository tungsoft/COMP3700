public interface OrderLineIterable {
    boolean hasNext();
    OrderLine next();

    public void reset();
}
