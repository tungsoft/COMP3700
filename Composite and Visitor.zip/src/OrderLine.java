public class OrderLine {

    private Product product;
    private double quantity;
    private double cost;

    public OrderLine(Product product, double quantity) {
        this.product = product;
        this.quantity = quantity;
        this.cost = product.getPrice() * quantity;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }


    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
}
