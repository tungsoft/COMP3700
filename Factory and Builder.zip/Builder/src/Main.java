public class Main {

    public static void main(String[] args) {
        System.out.println("Hello World!");

        ReceiptBuilder builder = new TXTReceiptBuilder();

        builder.setHeader("Smith's store", 1001,"Anna", "Adam", "11/11/2017 9:00 am");
        builder.addLine(101, "Apple", 2.5, 0.99);
        builder.addLine(102, "Orange", 3.1, 1.99);

        builder.setFooter("10.49", "1.23");

        System.out.println(builder.toString());

    }
}
