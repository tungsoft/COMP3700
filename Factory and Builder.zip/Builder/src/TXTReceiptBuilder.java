public class TXTReceiptBuilder implements ReceiptBuilder {
    StringBuilder str = new StringBuilder();
    @Override
    public void setHeader(String storename, int orderID, String cashier, String customer, String date) {
        str.append("----------------------------------\n");
        str.append(storename); str.append('\n');
        str.append("Order Number: " + String.valueOf(orderID) + "\n");
        str.append("Cashier: " + cashier + "\n");
        str.append("Customer: " + customer + "\n");
        str.append("Date:" + date + "\n");
        str.append("ProdID      Product     Qty    Price   Total   Tax\n");
        str.append("----------------------------------\n");
    }

    @Override
    public void setFooter(String totalCost, String totalTax) {
        str.append("----------------------------------\n");
        str.append("Total: " + totalCost + "\n");
        str.append("Total tax: " + totalTax + "\n");
    }

    @Override
    public void addLine(int productID, String productName, double qty, double price) {
        str.append(productID); str.append('\t');
        str.append(productName); str.append('\t');
        str.append(qty); str.append('\t');
        str.append(price); str.append('\t');
        str.append(qty * price); str.append('\t');
        str.append(qty * price * 0.09); str.append('\n');
    }

    @Override
    public String toString() {
        return str.toString();
    }
}
