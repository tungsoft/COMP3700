public interface ReceiptBuilder {
    public void setHeader(String storename, int orderID, String cashier, String customer, String date);
    public void addLine(int productID, String productName, double qty, double price);
    public void setFooter(String totalCost, String totalTax);
    public String toString();
}
