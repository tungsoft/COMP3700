public class WindowsButton implements Button {
    private String text;
    public WindowsButton(String text) {
        this.text = text;
    }

    @Override
    public String getText() {
        return text;
    }

    @Override
    public void paint() {
        System.out.println("I am a Windows button with a caption of " + text);
    }
}
