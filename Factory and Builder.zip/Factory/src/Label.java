public interface Label {
    public String getText();
    public void paint();
}

