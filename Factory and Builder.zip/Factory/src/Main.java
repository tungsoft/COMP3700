
public class Main {

    public static void main(String[] args) {
        GUIFactory factory = null;
        if (args[0].equals("Windows"))
            factory = new GUIWindowsFactory();
        else
            if (args[0].equals("Mac"))
                factory = new GUIMacFactory();

        Button btn1 = factory.createButton("Hello World!");
        Label lab1 = factory.createLabel("Factory demo!");

        btn1.paint();
        lab1.paint();
    }
}
