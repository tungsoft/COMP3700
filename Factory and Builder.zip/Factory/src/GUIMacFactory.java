public class GUIMacFactory implements GUIFactory {
    @Override
    public Button createButton(String text) {
        MacButton button = new MacButton(text);
        return button;
    }

    public Label createLabel(String text) {
        MacLabel obj = new MacLabel(text);
        return obj;
    }

}