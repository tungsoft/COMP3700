public class GUIWindowsFactory implements GUIFactory {
    @Override
    public Button createButton(String text) {
        WindowsButton button = new WindowsButton(text);
        return button;
    }

    public Label createLabel(String text) {
        WindowsLabel obj = new WindowsLabel(text);
        return obj;
    }

}
