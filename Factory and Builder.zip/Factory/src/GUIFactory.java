import javax.swing.*;

public interface GUIFactory {
    public Button createButton(String text);
    public Label  createLabel(String text);
//    public TextField createTextField();
    // ...
}
