public interface Button {
    public String getText();
    public void paint();
}
