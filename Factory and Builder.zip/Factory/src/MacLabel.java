public class MacLabel implements Label {
    private String text;
    public MacLabel(String text) {
        this.text = text;
    }

    @Override
    public String getText() {
        return text;
    }

    @Override
    public void paint() {
        System.out.println("I am a Mac label with a caption of " + text);
    }
}
