public class WindowsLabel implements Label {
    private String text;
    public WindowsLabel(String text) {
        this.text = text;
    }

    @Override
    public String getText() {
        return text;
    }

    @Override
    public void paint() {
        System.out.println("I am a Windows label with a caption of " + text);
    }
}
